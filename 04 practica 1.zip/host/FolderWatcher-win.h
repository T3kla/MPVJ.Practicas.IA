#ifndef	_FOLDERWATCHER_H_
#define	_FOLDERWATCHER_H_

void winhostext_WatchFolder(const char* startupScript);
void winhostext_Query();
void winhostext_CleanUp();

#endif //_FOLDERWATCHER_H_